data<-read.table("allele_calling_mod.txt")
write.table(t(data),file="allele_calling_mod2.txt", quote=FALSE, sep="\t")
